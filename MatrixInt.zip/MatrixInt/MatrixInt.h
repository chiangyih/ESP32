#ifndef MatrixInt1_H
#define MatrixInt1_H
#include <Arduino.h>
	static const byte led5   = 0b00100000;        //  red
	static const byte led6   = 0b01000000;        //  green
	static const byte led7   = 0b10000000;        //  blue
	static const byte led0 = 0b00000001;        //  ledSeg0
	static const byte led1 = 0b00000010;        //  ledSeg1
	static const byte led2 = 0b00000100;        //  ledSeg2
	static const byte led3 = 0b00001000;        //  ledSeg3
	static const byte led4 = 0b00010000;        //  ledSeg4
	static const byte ledOff = 0x00;          //  Off
	static const byte ledOn = 0x01;           //  On
void MatrixInt(int xnum, int oppp);
void MatrixLED(byte ledNum, int op);
void LEDon(byte ledNum);
void LEDoff(byte ledNum);
void MatrixLEDrssi(int32_t rssi);

#endif
#include "MatrixInt.h" //include the declaration for this class 
#include <Wire.h>
#define   addrPCF8574         0x20
#define   addrPCF8574A        0x38

byte addrLED = addrPCF8574;

void MatrixInt(int xnum, int oppp){
	switch (xnum)
    {
      case 0:
        MatrixLED(led0, oppp);
        break;
      case 1:
        MatrixLED(led1, oppp);
        break;
	  case 2:
        MatrixLED(led2, oppp);
        break;
      case 3:
        MatrixLED(led3, oppp);
        break;
      case 4:
        MatrixLED(led4, oppp);
        break;
      case 5:
        MatrixLED(led5, oppp);
        break;
	  case 6:
        MatrixLED(led6, oppp);
        break;
      case 7:
        MatrixLED(led7, oppp);
        break;		
    }
}

void MatrixLED(byte ledNum, int op){

  //  op =  0x00 : turn off
  //  op =  0x01 : turn on
  byte ledInput = 0;
  byte ledOutput = 0;
  String msg = "";
  Wire.requestFrom((int)addrLED, 1);
  while (Wire.available())
  {
    ledInput = Wire.read();
    switch (op)
    {
      case 0:
        //  turn LED off
        ledOutput = ledInput | ledNum;
        msg = "Trun Off ";
        break;
      case 1:
        //  turn LED on
        ledOutput = ledInput & ~ledNum;
        msg = "Trun On ";
        break;
      default:
        msg = "not command ";
        break;
    } //  switch (op)
    Wire.beginTransmission((int)addrLED);
    Wire.write(ledOutput);
    Wire.endTransmission();
  } //  while (Wire.available())
}
void LEDon(byte ledNum)
{
  MatrixLED(ledNum, ledOn);
} //  void LEDon(byte ledNum)

void LEDoff(byte ledNum)
{
  MatrixLED(ledNum, ledOff);
} //  void LEDoff(byte ledNum)

void MatrixLEDrssi(int32_t rssi){
if (rssi > -65)
  {
    MatrixInt(0, 1);//亮紅燈 
	MatrixInt(1, 1);
	MatrixInt(2, 1);
	MatrixInt(3, 1);
	MatrixInt(4, 1);
     
  }
  else if (rssi > -75)
  {
    MatrixInt(0, 1);//亮紅燈 
	MatrixInt(1, 1);
	MatrixInt(2, 1);
	MatrixInt(3, 1);
	MatrixInt(4, 0);
  }
  else if (rssi > -85)
  {
    MatrixInt(0, 1);//亮紅燈 
	MatrixInt(1, 1);
	MatrixInt(2, 1);
	MatrixInt(3, 0);
	MatrixInt(4, 0);
  }
  else if (rssi > -95)
  {
    MatrixInt(0, 1);//亮紅燈 
	MatrixInt(1, 1);
	MatrixInt(2, 0);
	MatrixInt(3, 0);
	MatrixInt(4, 0);
  }
  else if (rssi > -105)
  {
    MatrixInt(0, 1);//亮紅燈 
	MatrixInt(1, 0);
	MatrixInt(2, 0);
	MatrixInt(3, 0);
	MatrixInt(4, 0);
  }
  else
  {
    MatrixInt(0, 0);//亮紅燈 
	MatrixInt(1, 0);
	MatrixInt(2, 0);
	MatrixInt(3, 0);
	MatrixInt(4, 0);
  }
}
 
